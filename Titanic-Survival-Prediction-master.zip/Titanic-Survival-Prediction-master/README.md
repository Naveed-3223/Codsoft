# Titanic-Survival-Prediction
Titanic survival predication model for beginners using Jupyter Notebook.


In this there is a step by step process of creating a model for predicting survival of passengers in Titanic Disaster.

Note: train.csv is the training data set and test.csv is the dataset to which prediction is made.
      submission.csv is the output file
